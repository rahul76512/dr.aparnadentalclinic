
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Calendar, Globe } from 'lucide-react';
import { useLanguage } from './LanguageContext';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { language, setLanguage, t } = useLanguage();
  const location = useLocation();

  const navLinks = [
    { name: t('nav.home'), path: '/' },
    { name: t('nav.about'), path: '/about' },
    { name: t('nav.services'), path: '/services' },
    { name: t('nav.treatment'), path: '/treatment' },
    { name: t('nav.reviews'), path: '/reviews' },
    { name: t('nav.gallery'), path: '/gallery' },
    { name: t('nav.contact'), path: '/contact' },
  ];

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <Link to="/" className="flex flex-col">
              <span className="text-blue-600 font-bold text-lg md:text-xl leading-tight uppercase font-poppins">Dr. Aparna</span>
              <span className="text-slate-500 text-[10px] md:text-xs font-medium uppercase tracking-wider">Multispeciality Dental Clinic</span>
            </Link>
          </div>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center space-x-6">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-semibold transition-colors duration-200 ${
                  location.pathname === link.path ? 'text-blue-600' : 'text-slate-600 hover:text-blue-600'
                }`}
              >
                {link.name}
              </Link>
            ))}
            
            <button 
              onClick={toggleLanguage}
              className="flex items-center space-x-1 px-3 py-1 rounded-full border border-blue-100 bg-blue-50 text-blue-600 hover:bg-blue-100 transition-all"
            >
              <Globe size={16} />
              <span className="text-xs font-bold uppercase">{language === 'en' ? 'HI' : 'EN'}</span>
            </button>

            <Link
              to="/book"
              className="bg-blue-600 text-white px-5 py-2.5 rounded-lg font-bold text-sm hover:bg-blue-700 transition-all flex items-center shadow-lg shadow-blue-200"
            >
              <Calendar size={18} className="mr-2" />
              {t('nav.book')}
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden flex items-center space-x-4">
             <button 
              onClick={toggleLanguage}
              className="flex items-center space-x-1 px-2 py-1 rounded-md border border-blue-100 bg-blue-50 text-blue-600"
            >
              <Globe size={14} />
              <span className="text-[10px] font-bold uppercase">{language === 'en' ? 'HI' : 'EN'}</span>
            </button>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-600 hover:text-blue-600"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="lg:hidden bg-white border-t border-slate-100 absolute w-full shadow-xl">
          <div className="px-4 pt-2 pb-6 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className={`block px-3 py-4 text-base font-semibold border-b border-slate-50 ${
                  location.pathname === link.path ? 'text-blue-600 bg-blue-50/50' : 'text-slate-600'
                }`}
              >
                {link.name}
              </Link>
            ))}
            <Link
              to="/book"
              onClick={() => setIsOpen(false)}
              className="block mt-4 bg-blue-600 text-white text-center py-4 rounded-xl font-bold text-lg"
            >
              {t('nav.book')}
            </Link>
            <a
              href="tel:8588087214"
              className="block mt-2 bg-slate-100 text-slate-800 text-center py-4 rounded-xl font-bold text-lg flex items-center justify-center"
            >
              <Phone size={20} className="mr-2" />
              Call Now
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
