
import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Clock, Mail, MessageCircle } from 'lucide-react';
import { useLanguage } from './LanguageContext';

const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
        <div>
          <h3 className="text-white font-bold text-xl mb-6 uppercase tracking-wider font-poppins">Dr. Aparna Clinic</h3>
          <p className="text-sm leading-relaxed mb-6">
            Providing advanced multispeciality dental care with a focus on painless treatment and patient comfort. Your smile is our priority.
          </p>
          <div className="flex space-x-4">
            <a href="https://wa.me/918588087214" className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center hover:bg-green-600 transition-colors">
              <MessageCircle size={20} />
            </a>
            <a href="tel:8588087214" className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors">
              <Phone size={20} />
            </a>
          </div>
        </div>

        <div>
          <h3 className="text-white font-bold text-lg mb-6 font-poppins">{t('footer.links')}</h3>
          <ul className="space-y-4 text-sm">
            <li><Link to="/" className="hover:text-blue-400 transition-colors">Home</Link></li>
            <li><Link to="/about" className="hover:text-blue-400 transition-colors">About Doctor</Link></li>
            <li><Link to="/services" className="hover:text-blue-400 transition-colors">Our Services</Link></li>
            <li><Link to="/gallery" className="hover:text-blue-400 transition-colors">Photo Gallery</Link></li>
            <li><Link to="/contact" className="hover:text-blue-400 transition-colors">Contact Us</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="text-white font-bold text-lg mb-6 font-poppins">{t('footer.address')}</h3>
          <ul className="space-y-4 text-sm">
            <li className="flex items-start">
              <MapPin size={18} className="mr-3 text-blue-500 shrink-0" />
              <span>
                Shop NO A 61, Phase 1, Shani Bazaar Street,<br />
                Near MCD Primary School, Goyla Dairy,<br />
                Qutub Vihar, New Delhi, Delhi 110071
              </span>
            </li>
            <li className="flex items-center">
              <Phone size={18} className="mr-3 text-blue-500" />
              <span>+91 8588087214</span>
            </li>
            <li className="flex items-center">
              <Mail size={18} className="mr-3 text-blue-500" />
              <span>info@draparnadental.com</span>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="text-white font-bold text-lg mb-6 font-poppins">{t('footer.hours')}</h3>
          <ul className="space-y-4 text-sm">
            <li className="flex items-start justify-between">
              <span className="flex items-center"><Clock size={16} className="mr-2 text-blue-500" /> Mon - Sat</span>
              <div className="text-right">
                10:00 AM – 02:00 PM<br />
                05:00 PM – 09:00 PM
              </div>
            </li>
            <li className="flex items-center justify-between">
              <span>Sunday</span>
              <span className="text-red-400 font-semibold">Closed</span>
            </li>
            <li className="pt-4 border-t border-slate-800">
               <span className="text-xs italic text-slate-500 font-medium">Emergency visits available on call.</span>
            </li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16 pt-8 border-t border-slate-800 text-center">
        <p className="text-xs text-slate-500 uppercase tracking-widest">{t('footer.copyright')}</p>
      </div>
    </footer>
  );
};

export default Footer;
