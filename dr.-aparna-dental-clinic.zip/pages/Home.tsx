
import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, CheckCircle2, Star, ArrowRight, Shield, Award, HeartPulse, Clock, Heart, Users } from 'lucide-react';
import { useLanguage } from '../components/LanguageContext';

const Home: React.FC = () => {
  const { t } = useLanguage();

  const services = [
    { title: 'Root Canal Treatment', icon: <Shield className="text-blue-600" size={32} />, desc: 'Painless RCT to save your natural teeth.' },
    { title: 'Wisdom Tooth Extraction', icon: <Shield className="text-blue-600" size={32} />, desc: 'Safe and surgical removal of wisdom teeth.' },
    { title: 'Tooth Reshaping', icon: <Shield className="text-blue-600" size={32} />, desc: 'Cosmetic contouring for a perfect smile.' },
    { title: 'Bleeding Gums Treatment', icon: <HeartPulse className="text-blue-600" size={32} />, desc: 'Advanced periodontal care for gum health.' },
    { title: 'Maxillofacial Prosthetics', icon: <Shield className="text-blue-600" size={32} />, desc: 'Custom prosthetic rehabilitation services.' },
    { title: 'Oral & Maxillofacial Surgery', icon: <Shield className="text-blue-600" size={32} />, desc: 'Expert surgical procedures for oral health.' },
  ];

  const features = [
    { text: t('whyChoose.experience'), icon: <Award className="text-blue-600" /> },
    { text: t('whyChoose.hygiene'), icon: <Shield className="text-blue-600" /> },
    { text: t('whyChoose.affordable'), icon: <Heart className="text-blue-600" /> },
    { text: t('whyChoose.emergency'), icon: <Clock className="text-blue-600" /> },
    { text: t('whyChoose.accessible'), icon: <Users className="text-blue-600" /> },
    { text: t('whyChoose.expert'), icon: <Star className="text-blue-600" /> },
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative bg-slate-50 pt-16 pb-24 md:pt-24 md:pb-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-12 items-center">
          <div className="z-10">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-blue-100 text-blue-700 text-sm font-bold mb-6">
              <span className="relative flex h-3 w-3 mr-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
              </span>
              Trusted by 5000+ Happy Patients
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-slate-900 mb-6 leading-tight font-poppins">
              {t('hero.heading')}
            </h1>
            <p className="text-lg md:text-xl text-slate-600 mb-10 leading-relaxed font-medium">
              {t('hero.subheading')}
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link
                to="/book"
                className="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-all text-center shadow-xl shadow-blue-200"
              >
                {t('hero.bookBtn')}
              </Link>
              <a
                href="tel:8588087214"
                className="bg-white text-slate-800 border-2 border-slate-200 px-8 py-4 rounded-xl font-bold text-lg hover:bg-slate-50 transition-all flex items-center justify-center"
              >
                <Phone size={20} className="mr-2" />
                {t('hero.callBtn')}
              </a>
            </div>
            
            <div className="mt-12 flex items-center space-x-6">
              <div className="flex -space-x-3">
                {[1,2,3,4].map(i => (
                  <img key={i} src={`https://picsum.photos/seed/${i+10}/40/40`} className="w-10 h-10 rounded-full border-2 border-white" alt="Patient" />
                ))}
              </div>
              <div>
                <div className="flex text-yellow-400">
                  <Star size={16} fill="currentColor" />
                  <Star size={16} fill="currentColor" />
                  <Star size={16} fill="currentColor" />
                  <Star size={16} fill="currentColor" />
                  <Star size={16} fill="currentColor" />
                </div>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-wider mt-1">4.9/5 Rating (600+ Google Reviews)</p>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-blue-100 rounded-full mix-blend-multiply filter blur-2xl opacity-70 animate-pulse"></div>
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-sky-100 rounded-full mix-blend-multiply filter blur-2xl opacity-70 animate-pulse"></div>
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-8 border-white">
              <img 
                src="https://images.unsplash.com/photo-1629909605125-58da120bc0aa?auto=format&fit=crop&q=80&w=1000" 
                alt="Modern Dental Clinic"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 font-poppins mb-4 uppercase tracking-tight">{t('whyChoose.title')}</h2>
            <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, idx) => (
              <div key={idx} className="p-8 rounded-2xl bg-blue-50 border border-blue-100 hover:shadow-lg transition-all group">
                <div className="w-14 h-14 bg-white rounded-xl shadow-sm flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">{feature.text}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">Dedicated to providing top-notch healthcare with the latest medical advancements.</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 font-poppins mb-4 uppercase">{t('nav.services')}</h2>
              <p className="text-slate-600 max-w-2xl font-medium">From routine checkups to advanced surgical procedures, we provide comprehensive dental care for all ages.</p>
            </div>
            <Link to="/services" className="mt-6 md:mt-0 text-blue-600 font-bold flex items-center hover:translate-x-1 transition-transform">
              View All Services <ArrowRight size={20} className="ml-2" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, idx) => (
              <div key={idx} className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:border-blue-200 hover:shadow-xl transition-all">
                <div className="mb-6">{service.icon}</div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h3>
                <p className="text-slate-500 text-sm mb-6 leading-relaxed">{service.desc}</p>
                <Link to="/treatment" className="text-blue-600 text-sm font-bold flex items-center group">
                  Learn More <ArrowRight size={16} className="ml-1 opacity-0 group-hover:opacity-100 transition-all" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Emergency Banner */}
      <section className="bg-blue-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-4xl font-bold text-white mb-8 font-poppins">{t('emergencyBanner.text')}</h2>
          <a
            href="tel:8588087214"
            className="bg-white text-blue-600 px-10 py-4 rounded-xl font-bold text-xl hover:bg-slate-100 transition-all inline-flex items-center shadow-2xl shadow-blue-900/20"
          >
            <Phone size={24} className="mr-3" />
            {t('emergencyBanner.btn')}
          </a>
        </div>
      </section>

      {/* Before/After Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
             <h2 className="text-3xl md:text-4xl font-bold text-slate-900 font-poppins mb-4 uppercase">Smile Transformations</h2>
             <p className="text-slate-600 max-w-2xl mx-auto">Real results from our actual patients. Experience the difference expert care makes.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {[1, 2, 3].map(i => (
              <div key={i} className="group overflow-hidden rounded-2xl shadow-lg border border-slate-100">
                <div className="relative aspect-[4/3]">
                  <img 
                    src={`https://picsum.photos/seed/dental${i}/800/600`} 
                    alt="Transformation" 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute top-4 left-4 bg-blue-600 text-white px-3 py-1 rounded text-xs font-bold uppercase tracking-widest">Result {i}</div>
                </div>
                <div className="p-6 bg-white">
                   <p className="text-slate-900 font-bold">Comprehensive Smile Makeover</p>
                   <p className="text-slate-500 text-sm mt-1">Duration: 3 Sessions</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-slate-900">
           <img src="https://picsum.photos/seed/bgclinic/1600/900" className="w-full h-full object-cover opacity-20" alt="Clinic" />
        </div>
        <div className="max-w-4xl mx-auto px-4 relative z-10 text-center">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-8 font-poppins leading-tight">Ready to Restore Your Smile Confidence?</h2>
          <p className="text-xl text-slate-300 mb-12">Book your consultation today and take the first step towards perfect oral health.</p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <Link
              to="/book"
              className="bg-blue-600 text-white px-10 py-5 rounded-xl font-bold text-xl hover:bg-blue-700 transition-all shadow-2xl shadow-blue-500/20"
            >
              Book Appointment Now
            </Link>
            <a
              href="https://wa.me/918588087214"
              className="bg-green-500 text-white px-10 py-5 rounded-xl font-bold text-xl hover:bg-green-600 transition-all shadow-2xl shadow-green-500/20 flex items-center justify-center"
            >
              <CheckCircle2 size={24} className="mr-3" />
              Chat on WhatsApp
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
