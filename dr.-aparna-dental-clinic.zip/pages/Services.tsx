
import React from 'react';
import { ShieldCheck, Info, CheckCircle, Clock } from 'lucide-react';

const Services: React.FC = () => {
  const detailedServices = [
    {
      id: 'rct',
      title: 'Root Canal Treatment (RCT)',
      description: 'A procedure to save a tooth that is badly decayed or becomes infected. We use advanced rotary systems for faster, painless results.',
      benefits: ['Stops pain immediately', 'Prevents tooth loss', 'Maintains natural tooth function'],
      procedure: ['Removal of infected pulp', 'Cleaning & shaping canals', 'Sealing with bio-compatible material'],
      recovery: 'Usually 24-48 hours of mild sensitivity. Resume normal activity next day.'
    },
    {
      id: 'extraction',
      title: 'Wisdom Tooth Extraction',
      description: 'Surgical or non-surgical removal of impacted wisdom teeth causing pain, crowding or infection.',
      benefits: ['Relieves jaw pressure', 'Prevents future misalignment', 'Eliminates infection source'],
      procedure: ['Local anesthesia', 'Gentle tooth luxation', 'Suturing if necessary'],
      recovery: '3-7 days for complete soft tissue healing. Liquid diet for 24 hours.'
    },
    {
      id: 'reshaping',
      title: 'Tooth Reshaping',
      description: 'Cosmetic contouring to improve the appearance of chipped, cracked or poorly aligned teeth.',
      benefits: ['Instant aesthetic improvement', 'Permanent results', 'Painless procedure'],
      procedure: ['Enamel contouring', 'Smoothing edges', 'Final polishing'],
      recovery: 'No recovery time needed. Results are immediate.'
    },
    {
      id: 'gums',
      title: 'Bleeding Gums Treatment',
      description: 'Scaling and root planing to treat gingivitis and periodontitis, restoring gum health.',
      benefits: ['Fresh breath', 'Healthy, non-bleeding gums', 'Prevents tooth mobility'],
      procedure: ['Deep cleaning', 'Plaque removal', 'Antibacterial irrigation'],
      recovery: 'Gums may be tender for 1-2 days. Salt water rinses recommended.'
    }
  ];

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      <div className="bg-white py-16 mb-16 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-slate-900 mb-4 uppercase font-poppins tracking-tight">Our Specialized Services</h1>
          <p className="text-slate-600 max-w-2xl mx-auto">Comprehensive dental solutions using cutting-edge technology and medical expertise.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 space-y-16">
        {detailedServices.map((service, idx) => (
          <div key={idx} className={`bg-white rounded-3xl overflow-hidden shadow-lg flex flex-col ${idx % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'}`}>
            <div className="lg:w-2/5 relative min-h-[300px]">
              <img 
                src={`https://picsum.photos/seed/${service.id}/800/1000`} 
                alt={service.title}
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-8 left-8 right-8">
                 <h2 className="text-white text-3xl font-bold font-poppins">{service.title}</h2>
              </div>
            </div>
            
            <div className="lg:w-3/5 p-8 lg:p-12">
              <p className="text-slate-600 text-lg leading-relaxed mb-8">{service.description}</p>
              
              <div className="grid md:grid-cols-2 gap-8 mb-8">
                <div>
                  <h4 className="flex items-center text-blue-600 font-bold mb-4">
                    <CheckCircle size={18} className="mr-2" /> Key Benefits
                  </h4>
                  <ul className="space-y-2">
                    {service.benefits.map((b, i) => (
                      <li key={i} className="text-slate-500 text-sm flex items-start">
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-200 mt-1.5 mr-3 shrink-0"></span>
                        {b}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="flex items-center text-blue-600 font-bold mb-4">
                    <Info size={18} className="mr-2" /> Procedure Details
                  </h4>
                  <ul className="space-y-2">
                    {service.procedure.map((p, i) => (
                      <li key={i} className="text-slate-500 text-sm flex items-start">
                         <span className="font-bold text-slate-300 mr-2">{i+1}.</span>
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="p-6 bg-slate-50 rounded-2xl flex items-start">
                 <Clock size={24} className="text-blue-600 mr-4 shrink-0" />
                 <div>
                    <h5 className="font-bold text-slate-900 mb-1">Recovery Information</h5>
                    <p className="text-sm text-slate-500">{service.recovery}</p>
                 </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;
