
import React from 'react';
import { Star, Quote } from 'lucide-react';

const Reviews: React.FC = () => {
  const reviews = [
    {
      name: "Amit Kumar",
      rating: 5,
      comment: "Very professional staff and Dr. Aparna is very knowledgeable. My root canal was completely painless. Highly recommended!",
      date: "2 weeks ago"
    },
    {
      name: "Priya Sharma",
      rating: 5,
      comment: "The clinic is super clean and hygienic. Best place for dental checkups in Qutub Vihar. Very affordable prices compared to others.",
      date: "1 month ago"
    },
    {
      name: "Rajesh Singh",
      rating: 4.9,
      comment: "Got my wisdom tooth removed here. I was very scared but the doctor made me feel comfortable. The recovery was quick.",
      date: "3 months ago"
    },
    {
      name: "Sneha Gupta",
      rating: 5,
      comment: "Excellent treatment for bleeding gums. I can see a visible difference in just two sessions. The staff is very polite.",
      date: "4 months ago"
    },
    {
      name: "Vikas Verma",
      rating: 5,
      comment: "Dr. Aparna explains everything so clearly. No hidden costs. One of the most honest dental clinics I've visited.",
      date: "6 months ago"
    }
  ];

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      <div className="bg-white py-24 mb-16 shadow-sm border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="inline-block bg-blue-50 text-blue-600 px-4 py-1 rounded-full text-sm font-bold uppercase mb-6">Patient Satisfaction</div>
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-8 font-poppins uppercase">Patient Reviews</h1>
          
          <div className="flex flex-col items-center">
             <div className="flex text-yellow-400 mb-4 scale-150">
               {[1,2,3,4,5].map(i => <Star key={i} fill="currentColor" size={24} />)}
             </div>
             <p className="text-4xl font-black text-slate-900 mb-1">4.9 / 5.0</p>
             <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Based on 600+ Google Reviews</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {reviews.map((review, idx) => (
          <div key={idx} className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl transition-all relative">
            <Quote className="absolute top-8 right-8 text-blue-50" size={64} />
            <div className="relative z-10">
              <div className="flex text-yellow-400 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} fill={i < Math.floor(review.rating) ? "currentColor" : "none"} stroke="currentColor" />
                ))}
              </div>
              <p className="text-slate-700 italic leading-relaxed mb-8 text-lg">"{review.comment}"</p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-xl mr-4 uppercase">
                  {review.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">{review.name}</h4>
                  <p className="text-xs text-slate-400 uppercase font-bold tracking-wider">{review.date}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="text-center mt-20">
         <a 
           href="https://www.google.com/maps" 
           target="_blank" 
           rel="noopener noreferrer"
           className="bg-white border-2 border-slate-200 px-8 py-4 rounded-xl font-bold text-slate-800 hover:bg-slate-50 transition-all inline-flex items-center"
         >
           View More on Google
         </a>
      </div>
    </div>
  );
};

export default Reviews;
