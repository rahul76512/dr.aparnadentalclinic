
import React, { useState } from 'react';
import { MapPin, Phone, MessageCircle, Clock, Send, Check } from 'lucide-react';

const Contact: React.FC = () => {
  const [formStatus, setFormStatus] = useState<'idle' | 'sending' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('sending');
    setTimeout(() => setFormStatus('success'), 1500);
  };

  return (
    <div className="bg-slate-50 min-h-screen">
      <div className="bg-white py-16 mb-16 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-slate-900 mb-4 font-poppins uppercase tracking-tight">Contact Us</h1>
          <p className="text-slate-600">Reach out to us for appointments or any dental emergencies.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 pb-24">
        <div className="grid lg:grid-cols-3 gap-12">
          {/* Contact Details */}
          <div className="lg:col-span-1 space-y-8">
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
               <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 mb-6">
                  <MapPin size={24} />
               </div>
               <h3 className="text-lg font-bold text-slate-900 mb-3">Clinic Location</h3>
               <p className="text-slate-500 leading-relaxed">
                  Shop NO A 61, Phase 1, Shani Bazaar Street,
                  Near MCD Primary School, Goyla Dairy,
                  Qutub Vihar, New Delhi, Delhi 110071
               </p>
            </div>

            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
               <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center text-green-600 mb-6">
                  <MessageCircle size={24} />
               </div>
               <h3 className="text-lg font-bold text-slate-900 mb-3">WhatsApp & Phone</h3>
               <p className="text-slate-500 mb-4">+91 8588087214</p>
               <div className="flex space-x-3">
                  <a href="https://wa.me/918588087214" className="bg-green-500 text-white px-4 py-2 rounded-lg text-sm font-bold">WhatsApp Now</a>
                  <a href="tel:8588087214" className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-bold">Call Clinic</a>
               </div>
            </div>

            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
               <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-slate-600 mb-6">
                  <Clock size={24} />
               </div>
               <h3 className="text-lg font-bold text-slate-900 mb-3">Working Hours</h3>
               <div className="space-y-2 text-slate-500">
                  <p className="flex justify-between"><span>Mon - Sat</span> <span>10:00 AM - 09:00 PM</span></p>
                  <p className="text-xs italic text-slate-400 mt-2">Closed between 02:00 PM and 05:00 PM</p>
                  <p className="flex justify-between text-red-400 font-bold"><span>Sunday</span> <span>Closed</span></p>
               </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white p-10 md:p-16 rounded-[3rem] shadow-xl border border-slate-100 h-full">
              <h2 className="text-3xl font-bold text-slate-900 mb-8 font-poppins uppercase">Send a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Your Name</label>
                    <input required type="text" className="w-full px-5 py-4 rounded-xl bg-slate-50 border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all" placeholder="John Doe" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Email Address</label>
                    <input required type="email" className="w-full px-5 py-4 rounded-xl bg-slate-50 border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all" placeholder="john@example.com" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Subject</label>
                  <select className="w-full px-5 py-4 rounded-xl bg-slate-50 border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all">
                    <option>General Inquiry</option>
                    <option>Appointment Request</option>
                    <option>Dental Emergency</option>
                    <option>Feedback</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Message</label>
                  <textarea required rows={5} className="w-full px-5 py-4 rounded-xl bg-slate-50 border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all" placeholder="Tell us how we can help you..."></textarea>
                </div>
                
                <button 
                  type="submit" 
                  disabled={formStatus !== 'idle'}
                  className={`w-full py-5 rounded-2xl font-bold text-xl flex items-center justify-center transition-all ${
                    formStatus === 'success' ? 'bg-green-500 text-white' : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                >
                  {formStatus === 'idle' && <><Send size={20} className="mr-3" /> Send Message</>}
                  {formStatus === 'sending' && "Sending..."}
                  {formStatus === 'success' && <><Check size={24} className="mr-3" /> Message Sent Successfully!</>}
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Map Embed */}
        <div className="mt-20 rounded-[3rem] overflow-hidden shadow-2xl h-[500px] border-8 border-white">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3503.791539234856!2d77.03713837617415!3d28.57601337569502!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1af8e7920783%3A0xc6df707253503028!2sDr.%20Aparna%20Dental%20Clinic!5e0!3m2!1sen!2sin!4v1714582312345!5m2!1sen!2sin" 
            width="100%" 
            height="100%" 
            style={{ border: 0 }} 
            allowFullScreen 
            loading="lazy"
          ></iframe>
        </div>
      </div>
    </div>
  );
};

export default Contact;
