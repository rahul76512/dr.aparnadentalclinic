
import React from 'react';
// Added Heart and Star to imports to fix missing component errors
import { Award, GraduationCap, CheckCircle, ShieldCheck, Heart, Star } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="bg-white min-h-screen">
      <div className="bg-slate-50 py-16 mb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-slate-900 mb-4 font-poppins uppercase tracking-tight">About Dr. Aparna</h1>
          <p className="text-slate-600 max-w-2xl mx-auto text-lg font-medium">Expert care with 12 years of clinical excellence in multispeciality dental treatments.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-32">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="absolute inset-0 bg-blue-100 rounded-3xl transform rotate-3 translate-x-4 translate-y-4"></div>
            <img 
              src="https://images.unsplash.com/photo-1559839734-2b71f1536783?auto=format&fit=crop&q=80&w=800" 
              alt="Dr. Aparna"
              className="relative rounded-3xl shadow-xl w-full aspect-[4/5] object-cover"
            />
          </div>
          
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-6 font-poppins">Dr. Aparna</h2>
            <p className="text-blue-600 font-bold text-xl mb-8">BDS (Vinoba Bhave University, 2013) | Dental Surgeon</p>
            
            <div className="space-y-6 text-slate-600 leading-relaxed text-lg mb-10">
              <p>
                Dr. Aparna is a highly skilled dental surgeon with over 12 years of hands-on experience in providing advanced dental care. Since graduating in 2013, she has dedicated her career to perfecting the art of painless dentistry and aesthetic reconstruction.
              </p>
              <p>
                Her approach combines medical precision with a gentle touch, ensuring that patients feel relaxed and comfortable during even the most complex procedures. She is a firm believer in using the latest technology to achieve superior results while maintaining the highest standards of sterilization and hygiene.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {[
                { icon: <Award className="text-blue-600" />, title: "12+ Years Experience", subtitle: "Clinical Excellence" },
                { icon: <GraduationCap className="text-blue-600" />, title: "BDS Graduate", subtitle: "Vinoba Bhave Uni (2013)" },
                { icon: <ShieldCheck className="text-blue-600" />, title: "Verified Reg.", subtitle: "Medical Council Registered" },
                { icon: <CheckCircle className="text-blue-600" />, title: "Specialist", subtitle: "Advanced Treatments" }
              ].map((item, idx) => (
                <div key={idx} className="flex items-start space-x-4 p-4 rounded-xl border border-slate-100 bg-slate-50">
                  <div className="shrink-0">{item.icon}</div>
                  <div>
                    <h4 className="font-bold text-slate-900">{item.title}</h4>
                    <p className="text-sm text-slate-500">{item.subtitle}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <section className="py-24 bg-blue-600 text-white mb-20">
         <div className="max-w-7xl mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-12 font-poppins uppercase">Our Core Values</h2>
            <div className="grid md:grid-cols-3 gap-12">
               <div>
                  <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-6">
                     <ShieldCheck size={32} />
                  </div>
                  <h3 className="text-xl font-bold mb-4">Uncompromising Hygiene</h3>
                  <p className="text-blue-100 opacity-80">We follow international sterilization protocols for every single patient visit.</p>
               </div>
               <div>
                  <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-6">
                     <Heart size={32} />
                  </div>
                  <h3 className="text-xl font-bold mb-4">Patient Centricity</h3>
                  <p className="text-blue-100 opacity-80">Your comfort and understanding of the procedure are our top priorities.</p>
               </div>
               <div>
                  <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-6">
                     <Star size={32} />
                  </div>
                  <h3 className="text-xl font-bold mb-4">Ethical Treatment</h3>
                  <p className="text-blue-100 opacity-80">Honest advice and transparent pricing for all our dental services.</p>
               </div>
            </div>
         </div>
      </section>
    </div>
  );
};

export default About;
