
import React from 'react';
import { ClipboardList, Stethoscope, Microscope, CheckCircle } from 'lucide-react';

const Treatment: React.FC = () => {
  const steps = [
    {
      title: "Consultation & Examination",
      desc: "Comprehensive check-up using digital diagnostics to understand your unique dental needs.",
      icon: <Stethoscope size={40} className="text-blue-600" />
    },
    {
      title: "Treatment Planning",
      desc: "Detailed explanation of options, timelines, and costs. No hidden surprises.",
      icon: <ClipboardList size={40} className="text-blue-600" />
    },
    {
      title: "Precise Procedure",
      desc: "Execution of the treatment using pain-management techniques and advanced tools.",
      icon: <Microscope size={40} className="text-blue-600" />
    },
    {
      title: "Aftercare & Review",
      desc: "Follow-up support and guidance on maintaining your results for years to come.",
      icon: <CheckCircle size={40} className="text-blue-600" />
    }
  ];

  return (
    <div className="bg-white pb-24">
       <div className="bg-blue-600 py-24 text-white">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 font-poppins uppercase">Our Treatment Philosophy</h1>
          <p className="text-xl opacity-90 max-w-2xl mx-auto">We follow a patient-first approach, ensuring you are informed and comfortable at every step of your journey.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 mt-20">
        <div className="grid md:grid-cols-4 gap-8">
           {steps.map((step, idx) => (
             <div key={idx} className="relative group">
                <div className="mb-8 w-24 h-24 bg-blue-50 rounded-3xl flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
                   {step.icon}
                </div>
                {idx < 3 && (
                  <div className="hidden lg:block absolute top-12 left-32 w-full border-t-2 border-dashed border-slate-100"></div>
                )}
                <h3 className="text-xl font-bold text-slate-900 mb-4">{step.title}</h3>
                <p className="text-slate-500 leading-relaxed">{step.desc}</p>
             </div>
           ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 mt-32">
         <div className="bg-slate-50 rounded-[3rem] p-12 md:p-20 grid lg:grid-cols-2 gap-16 items-center">
            <div>
               <h2 className="text-3xl font-bold text-slate-900 mb-8 font-poppins uppercase">State-of-the-Art Technology</h2>
               <div className="space-y-6">
                  {[
                    "Digital X-Rays with 90% less radiation",
                    "Intra-oral cameras for real-time visualization",
                    "Advanced sterilization systems (Autoclave)",
                    "Ultrasonic scalers for painless cleaning",
                    "Rotary Endodontics for precise Root Canal"
                  ].map((item, i) => (
                    <div key={i} className="flex items-center space-x-4">
                       <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                          <CheckCircle size={14} className="text-blue-600" />
                       </div>
                       <span className="text-slate-700 font-medium">{item}</span>
                    </div>
                  ))}
               </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
               <img src="https://picsum.photos/seed/tool1/400/400" className="rounded-2xl shadow-md" alt="Equipment" />
               <img src="https://picsum.photos/seed/tool2/400/400" className="rounded-2xl shadow-md translate-y-8" alt="Equipment" />
            </div>
         </div>
      </div>
    </div>
  );
};

export default Treatment;
