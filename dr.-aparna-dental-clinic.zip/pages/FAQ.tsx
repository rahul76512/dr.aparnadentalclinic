
import React, { useState } from 'react';
import { Plus, Minus, HelpCircle } from 'lucide-react';

const FAQ: React.FC = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const faqs = [
    {
      q: "Is root canal treatment painful?",
      a: "With modern anesthesia and rotary techniques used at our clinic, most patients report that the procedure is no more painful than getting a filling. We focus on 'Painless Dentistry' for all our patients."
    },
    {
      q: "How often should I visit the dentist?",
      a: "We recommend a professional checkup and cleaning every 6 months to prevent tooth decay and maintain gum health. Regular visits can catch problems before they become painful or expensive."
    },
    {
      q: "What is the cost of basic dental treatments?",
      a: "Costs vary depending on the complexity of the case. However, we are known for offering highly affordable dental care without compromising on quality or hygiene. Please visit us for a free initial assessment."
    },
    {
      q: "Are emergency services available?",
      a: "Yes, we handle dental emergencies like severe toothaches, broken teeth, or gum trauma. Please call us directly at 8588087214 for priority emergency care."
    },
    {
      q: "What if I'm afraid of dental procedures?",
      a: "Dr. Aparna is experienced in handling dental anxiety. We use gentle communication, calming environments, and painless techniques to ensure a comfortable experience for nervous patients."
    },
    {
      q: "Does the clinic follow sterilization protocols?",
      a: "Absolutely. We use a high-pressure Autoclave for instrument sterilization and maintain a rigorous hygienic environment. Patient safety is our highest priority."
    }
  ];

  return (
    <div className="bg-slate-50 min-h-screen py-24">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-100 text-blue-600 rounded-full mb-8">
             <HelpCircle size={40} />
          </div>
          <h1 className="text-4xl font-bold text-slate-900 mb-4 font-poppins uppercase">Common Dental Questions</h1>
          <p className="text-slate-600">Get clarity on your dental concerns before your visit.</p>
        </div>

        <div className="space-y-4">
           {faqs.map((faq, idx) => (
             <div key={idx} className="bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm transition-all hover:shadow-md">
                <button 
                  onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
                  className="w-full flex items-center justify-between p-6 md:p-8 text-left transition-colors hover:bg-slate-50"
                >
                  <span className="text-lg font-bold text-slate-800">{faq.q}</span>
                  <div className={`shrink-0 ml-4 transition-transform duration-300 ${openIdx === idx ? 'rotate-180' : ''}`}>
                    {openIdx === idx ? <Minus className="text-blue-600" /> : <Plus className="text-slate-400" />}
                  </div>
                </button>
                <div className={`overflow-hidden transition-all duration-300 ease-in-out ${openIdx === idx ? 'max-h-96' : 'max-h-0'}`}>
                  <div className="p-8 pt-0 text-slate-600 leading-relaxed border-t border-slate-50">
                    {faq.a}
                  </div>
                </div>
             </div>
           ))}
        </div>

        <div className="mt-20 bg-blue-600 rounded-[3rem] p-12 text-center text-white">
           <h3 className="text-2xl font-bold mb-4 font-poppins">Still Have Questions?</h3>
           <p className="text-blue-100 mb-8 max-w-lg mx-auto">We're here to help. Feel free to reach out to us directly via WhatsApp or Phone for personalized advice.</p>
           <div className="flex flex-wrap justify-center gap-4">
              <a href="https://wa.me/918588087214" className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold hover:bg-slate-50 transition-all">Chat on WhatsApp</a>
              <a href="tel:8588087214" className="bg-blue-700 text-white px-8 py-4 rounded-xl font-bold hover:bg-blue-800 transition-all">Call 8588087214</a>
           </div>
        </div>
      </div>
    </div>
  );
};

export default FAQ;
