
import React, { useState } from 'react';
import { Calendar, User, Phone, MessageSquare, Briefcase, Clock } from 'lucide-react';
import { useLanguage } from '../components/LanguageContext';

const Book: React.FC = () => {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    service: '',
    date: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleWhatsAppBooking = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `Hello Dr. Aparna Dental Clinic, I would like to book an appointment.%0A%0A*Name:* ${formData.name}%0A*Phone:* ${formData.phone}%0A*Service:* ${formData.service}%0A*Date:* ${formData.date}%0A*Notes:* ${formData.message || 'None'}`;
    window.open(`https://wa.me/918588087214?text=${message}`, '_blank');
  };

  return (
    <div className="bg-slate-50 min-h-screen py-24">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden grid lg:grid-cols-5 border border-slate-100">
           {/* Info Side */}
           <div className="lg:col-span-2 bg-blue-600 p-10 md:p-12 text-white">
              <h1 className="text-3xl font-bold mb-8 font-poppins uppercase leading-tight">{t('booking.title')}</h1>
              <div className="space-y-8">
                 <div className="flex items-start">
                    <Clock size={24} className="mr-4 shrink-0 text-blue-200" />
                    <div>
                       <h4 className="font-bold">Clinic Hours</h4>
                       <p className="text-sm opacity-80">10:00 AM - 02:00 PM<br />05:00 PM - 09:00 PM</p>
                    </div>
                 </div>
                 <div className="flex items-start">
                    <Briefcase size={24} className="mr-4 shrink-0 text-blue-200" />
                    <div>
                       <h4 className="font-bold">Services</h4>
                       <p className="text-sm opacity-80">RCT, Implants, Cosmetic, Braces & More.</p>
                    </div>
                 </div>
                 <div className="pt-8 mt-8 border-t border-blue-500">
                    <p className="text-sm italic opacity-75">Your appointment request will be sent to our WhatsApp team. We will confirm the exact timing with you shortly.</p>
                 </div>
              </div>
           </div>

           {/* Form Side */}
           <div className="lg:col-span-3 p-10 md:p-12">
              <form onSubmit={handleWhatsAppBooking} className="space-y-6">
                 <div>
                    <label className="flex items-center text-sm font-bold text-slate-700 mb-2">
                       <User size={16} className="mr-2 text-blue-600" /> {t('booking.name')}
                    </label>
                    <input required type="text" name="name" onChange={handleChange} className="w-full px-5 py-4 rounded-xl bg-slate-50 border border-slate-200 focus:border-blue-500 outline-none transition-all" placeholder="Enter your full name" />
                 </div>
                 <div>
                    <label className="flex items-center text-sm font-bold text-slate-700 mb-2">
                       <Phone size={16} className="mr-2 text-blue-600" /> {t('booking.phone')}
                    </label>
                    <input required type="tel" name="phone" onChange={handleChange} className="w-full px-5 py-4 rounded-xl bg-slate-50 border border-slate-200 focus:border-blue-500 outline-none transition-all" placeholder="Enter mobile number" />
                 </div>
                 <div>
                    <label className="flex items-center text-sm font-bold text-slate-700 mb-2">
                       <Briefcase size={16} className="mr-2 text-blue-600" /> {t('booking.service')}
                    </label>
                    <select required name="service" onChange={handleChange} className="w-full px-5 py-4 rounded-xl bg-slate-50 border border-slate-200 focus:border-blue-500 outline-none transition-all">
                       <option value="">Choose a treatment...</option>
                       <option>Root Canal Treatment</option>
                       <option>Wisdom Tooth Extraction</option>
                       <option>Tooth Reshaping</option>
                       <option>Gums Treatment</option>
                       <option>Dental Implants</option>
                       <option>General Checkup</option>
                    </select>
                 </div>
                 <div>
                    <label className="flex items-center text-sm font-bold text-slate-700 mb-2">
                       <Calendar size={16} className="mr-2 text-blue-600" /> {t('booking.date')}
                    </label>
                    <input required type="date" name="date" onChange={handleChange} className="w-full px-5 py-4 rounded-xl bg-slate-50 border border-slate-200 focus:border-blue-500 outline-none transition-all" />
                 </div>
                 <div>
                    <label className="flex items-center text-sm font-bold text-slate-700 mb-2">
                       <MessageSquare size={16} className="mr-2 text-blue-600" /> {t('booking.message')}
                    </label>
                    <textarea name="message" rows={3} onChange={handleChange} className="w-full px-5 py-4 rounded-xl bg-slate-50 border border-slate-200 focus:border-blue-500 outline-none transition-all" placeholder="Special requirements (if any)"></textarea>
                 </div>
                 
                 <button type="submit" className="w-full bg-blue-600 text-white py-5 rounded-2xl font-bold text-xl hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 uppercase">
                    {t('booking.submit')}
                 </button>
              </form>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Book;
