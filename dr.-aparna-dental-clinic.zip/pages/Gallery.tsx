
import React, { useState } from 'react';

const Gallery: React.FC = () => {
  const [filter, setFilter] = useState('all');

  const categories = [
    { id: 'all', name: 'All Photos' },
    { id: 'clinic', name: 'Clinic Interior' },
    { id: 'treatment', name: 'Treatments' },
    { id: 'equipment', name: 'Equipment' }
  ];

  const photos = [
    { id: 1, cat: 'clinic', src: 'https://images.unsplash.com/photo-1629909605125-58da120bc0aa?auto=format&fit=crop&q=80&w=600' },
    { id: 2, cat: 'treatment', src: 'https://images.unsplash.com/photo-1598256989800-fe5f95da9787?auto=format&fit=crop&q=80&w=600' },
    { id: 3, cat: 'equipment', src: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&q=80&w=600' },
    { id: 4, cat: 'clinic', src: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=600' },
    { id: 5, cat: 'treatment', src: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&q=80&w=600' },
    { id: 6, cat: 'equipment', src: 'https://images.unsplash.com/photo-1629909609559-009f48f69299?auto=format&fit=crop&q=80&w=600' },
    { id: 7, cat: 'clinic', src: 'https://picsum.photos/seed/clinici/600/400' },
    { id: 8, cat: 'treatment', src: 'https://picsum.photos/seed/treati/600/400' },
    { id: 9, cat: 'equipment', src: 'https://picsum.photos/seed/equipi/600/400' },
  ];

  const filteredPhotos = filter === 'all' ? photos : photos.filter(p => p.cat === filter);

  return (
    <div className="bg-white pb-24 min-h-screen">
      <div className="bg-slate-50 py-24 mb-16 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-8 font-poppins uppercase">Our Gallery</h1>
        <div className="flex flex-wrap justify-center gap-4">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setFilter(cat.id)}
              className={`px-8 py-3 rounded-full font-bold text-sm transition-all ${
                filter === cat.id ? 'bg-blue-600 text-white shadow-lg' : 'bg-white text-slate-600 hover:bg-slate-100'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPhotos.map(photo => (
            <div key={photo.id} className="group relative overflow-hidden rounded-2xl aspect-square shadow-md">
              <img 
                src={photo.src} 
                alt="Clinic" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-blue-900/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                 <span className="text-white font-bold border-2 border-white px-6 py-2 rounded-lg scale-90 group-hover:scale-100 transition-transform">View Details</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Gallery;
